// This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
// Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
// session persistence, api calls, and more.
const Alexa = require('ask-sdk-core');

var admin = require("firebase-admin");

var serviceAccount = require("firebase.json");

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        const speakOutput = 'नमस्कार ..!! स्मार्ट होम ऑटोमेशन में आपका स्वागत है । में आपकी क्या सेवा कर सकती हूं?';
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};


const LightOnIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'LightOnIntent';
    },
     async handle(handlerInput) {

        try{
            

                     var app = admin.initializeApp({
                      credential: admin.credential.cert(serviceAccount),
                        databaseURL: "https://iottest-7498a.firebaseio.com"
                        });
              
                 await admin.database().ref("/ledstatus").set({
                        led:"1"
                    });
                 await app.delete();
                  const speakOutput = 'बिल्कुल जैसा आप कहे । मेने लाइट चालू कर दी है ।';
                     return handlerInput.responseBuilder
                     .speak(speakOutput)
                     .reprompt(speakOutput)
                     .getResponse(); 

      }catch(e){
            console.log(e);
            
        }
    
      
    }
};


const LightOffIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'LightOffIntent';
    },
     async handle(handlerInput) {
      
    try{
          var app = admin.initializeApp({
                      credential: admin.credential.cert(serviceAccount),
                        databaseURL: "https://iottest-7498a.firebaseio.com"
                        });
              
                 await admin.database().ref("/ledstatus").set({
                        led:"0"
                    });
                 await app.delete();
                  const speakOutput = 'बिल्कुल जैसा आप कहे । मेने लाइट बंध कर दी है ।';
                     return handlerInput.responseBuilder
                     .speak(speakOutput)
                     .reprompt(speakOutput)
                     .getResponse(); 

        
    }catch(e){
          console.log(e);
    }
    }
};

const DidNotUnderstandIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'DidNotUnderstandIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'माफ़ करें, डिवाइस ओन-ऑफ के सिवाय में किसी काम मे आपकी मदद नही कर सकती।।';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};



const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput =  'लाइट को कंट्रोल करने के लिऐ आप "लाइट चालू या बंध करो " एसा बोल सकते हो। ';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};


const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'मुझे खुशी हुई आपकी मदद करके!!';
        return handlerInput.responseBuilder
            .speak(speakOutput)
             .withShouldEndSession(true)
            .getResponse();
    }
};
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse();
    }
};

// The intent reflector is used for interaction model testing and debugging.
// It will simply repeat the intent the user said. You can create custom handlers
// for your intents by defining them above, then also adding them to the request
// handler chain below.
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

// Generic error handling to capture any syntax or routing errors. If you receive an error
// stating the request handler chain is not found, you have not implemented a handler for
// the intent being invoked or included it in the skill builder below.
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        console.log(`~~~~ Error handled: ${error.stack}`);
        const speakOutput = `Sorry, I had trouble doing what you asked. Please try again.`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

// The SkillBuilder acts as the entry point for your skill, routing all request and response
// payloads to the handlers above. Make sure any new handlers or interceptors you've
// defined are included below. The order matters - they're processed top to bottom.
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        LightOnIntentHandler,
        LightOffIntentHandler,
        DidNotUnderstandIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler, // make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers
    )
    .addErrorHandlers(
        ErrorHandler,
    )
    .lambda();
